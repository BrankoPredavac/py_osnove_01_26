ime_prezime: str = "Marko Maric"
oib: str = "4314325252"
email: str = "marko.maric@algebra.hr"
broj_telefona: str = "098/787-1234"
prosjecna_ocjena: float = 4.2
godina_upisa: int = 2005
naziv_studija: str = "PMF Biologija"
naziv_sveucilista: str = "Zagrebacko sveuciliste"


print(ime_prezime)
print(oib)
print(email)
print(broj_telefona)
print(godina_upisa)
print(naziv_studija)
print(naziv_sveucilista)
