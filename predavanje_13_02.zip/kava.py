da_li_kupac_zeli_espresso = input("Zelis li espress (Y/N)> ").strip().lower()
# "  Y  "
# "Y" nakon strip
# "y" nakon lower


if da_li_kupac_zeli_espresso == "y":
    print("Priprema esspresso ...")
    print("Esspresso gotov ...")
    print("Posluzujem esprersso ...")

print("Gotovo")
