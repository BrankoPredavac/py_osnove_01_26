def moja_funkcija(moja_varijabla: str):
    moja_varijabla.count()
