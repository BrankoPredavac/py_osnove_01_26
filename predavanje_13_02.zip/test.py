class Branko:
    def __init__(self, broj) -> None:
        self.broj = broj
        self.text = str(broj)


class novi_int:
    def __init__(self, broj) -> None:
        self.broj = broj
        self.text = str(broj)


moj_branko = novi_int(4)

print(moj_branko.broj)
