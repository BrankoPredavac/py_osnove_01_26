godine: float = 40.0


# godine = trenutna_godina - godian rodenja + (trentuni_mjesec - mjesec_rodenja)/12 + (trentuni_dan - dan_rodenja)/30
# godine = trenutna_godina - godian rodenja
