# Ovo je komentar

# fafafafa

# print("Ovo nije komentar")
print("Ovo komentar")

# Strancia trokuta u cm
a = 30

strancia_trokuta_a_cm = 30

# TODO: Popravi ovaj algoritam ne radi dobro
