tada = print("Dobra vecer")

print("Dobra", "vecer")

pozdrav = "Dobra vecer"

print(pozdrav)

pozdrav_dio_1 = "Dobra"
pozdrav_dio_2 = "vecer"

print(pozdrav_dio_1, pozdrav_dio_2)

print("Dobra", "vecer", "!!!!!!!!!!!!")

print("Dobra vecer")
print("Dobra", "vecer")
print("Dobra", "vecer", sep=" ++++++++++++++ ")
print("Dobra", "vecer", "!!!!!!!!!!!", sep=" ++++++++++++++ ")

# vrijednost1 + sep + vrijednost2 + sep + vrijednost3 + end
# vrijednost1 + end

print("Dobra vecer \n\n\n\t\tprijatelji  ")
print(r"Dobra vecer \n\n\n\t\tprijatelji  ")

print("Prije")
print()
print("\n", end="\n\n\n")
print("Poslije")


print("Dobra", "vecer", end="!!!!!!!")
print("Dobra", "vecer", end="!!!!!!!")

print()
print("Dobra", end="   ")
print("vecer", end="   ")
print("!!!!!!!!!!!!!!", end="   ")
print()
print("Dobra", "vecer", sep="-----------------", end="!!!!!!!")

print("Dobra", pozdrav_dio_1, end="   ")
