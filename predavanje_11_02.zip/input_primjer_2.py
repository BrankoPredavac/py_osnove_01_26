# help(input)

ime_korisnika = input("Unesite vase Ime> ")
prezime_korisnika = input("Unesite Vase Prezime> ")
# # prezime_korisnika = input(f"Dragi {ime_korisnika}, Unesite Vase Prezime> ")

print("Dobra vecer,", ime_korisnika, prezime_korisnika)

print("Gotovo")
