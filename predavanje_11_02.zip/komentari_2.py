Dobra = "Ante"

# $fasdfaf = 55


def funkcija_1():
    pass
    print("Nova funkcionalnost ")


# ovo je starnica trokuta a u cm
a = 545435


def moja_cool_funkcija():
    """Ta funkcija je super brzi alagoritam
    koji koriafsafaf 222222222222222
    """
    # Ta funkcija je super brzi alagoritam
    # koji koriafsafaf


# TODO: Nazovi ovo variijablu intuitvnije
moja_cool_funkcija()


foormula = a + 75754


# TODO: Napisi ovaj algoritma boolje, ideja uvedi kesiranja radi brzeg izvodenja
