# help(input)

ulaz_od_korisnika = input()
ulaz_od_korisnika_2 = input()


print("Gotovo")
